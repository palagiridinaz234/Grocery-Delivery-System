
<?php
$host="localhost";
$user="root";
$pass="";
$db="grocery2go";
// Create connection
$conn = mysqli_connect($host, $user, $pass, $db);
// Check connection

?>
