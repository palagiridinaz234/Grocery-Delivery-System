<?php
//extended to cart.php
//increment/decrement

require_once "ShoppingCart.php";

$id_mem=$_SESSION["cid"];
          $member_id =$id_mem;
$shoppingCart = new ShoppingCart();
if (! empty($_GET["action"])) {
    switch ($_GET["action"]) {
        case "add":
            if (! empty($_POST["quantity"])) {

                $productResult = $shoppingCart->getProductByCode($_GET["code"]);

                $cartResult = $shoppingCart->getCartItemByProduct($productResult[0]["id"], $member_id);

                if (! empty($cartResult)) {
                    // Update cart item quantity in database
                    $newQuantity = $cartResult[0]["quantity"] + $_POST["quantity"];
                    $shoppingCart->updateCartQuantity($newQuantity, $cartResult[0]["id"]);
                } else {
                    // Add to cart table
                    $time = date("H:i:s");
                    $date =date("m/d/y");
                    $shoppingCart->addToCart($productResult[0]["id"], $_POST["quantity"], $member_id,$date, $time);
                }
            }
            break;
        case "remove":
            // Delete single entry from the cart
            $shoppingCart->deleteCartItem($_GET["id"]);
            break;
        case "empty":
            // Empty cart
            $shoppingCart->emptyCart($member_id);
            break;
    }
}
?>
<HTML>
<HEAD>
<TITLE></TITLE>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="style1.css" type="text/css" rel="stylesheet" />
<script src="jquery-3.2.1.min.js"></script>
<script>
function increment_quantity(cart_id, price) {
    var inputQuantityElement = $("#input-quantity-"+cart_id);
    var newQuantity = parseInt($(inputQuantityElement).val())+1;
    var newPrice = newQuantity * price;

    save_to_db(cart_id, newQuantity, newPrice);
}

function decrement_quantity(cart_id, price) {
    var inputQuantityElement = $("#input-quantity-"+cart_id);
    if($(inputQuantityElement).val() > 1)
    {
    var newQuantity = parseInt($(inputQuantityElement).val()) - 1;
    var newPrice = newQuantity * price;

    save_to_db(cart_id, newQuantity, newPrice);
    }
}

function save_to_db(cart_id, new_quantity, newPrice) {
	var inputQuantityElement = $("#input-quantity-"+cart_id);
	var priceElement = $("#cart-price-"+cart_id);
    $.ajax({
		url : "update_cart_quantity.php",
		data : "cart_id="+cart_id+"&new_quantity="+new_quantity,
		type : 'post',
		success : function(response) {
			$(inputQuantityElement).val(new_quantity);
            $(priceElement).text("PHP"+newPrice);
            var totalQuantity = 0;
            $("input[id*='input-quantity-']").each(function() {
                var cart_quantity = $(this).val();
                totalQuantity = parseInt(totalQuantity) + parseInt(cart_quantity);
            });
            $("#total-quantity").text(totalQuantity);
            var totalItemPrice = 0;
            $("div[id*='cart-price-']").each(function() {
                var cart_price = $(this).text().replace("PHP","");
                totalItemPrice = parseInt(totalItemPrice) + parseInt(cart_price);
            });
            $("#total-price").text(totalItemPrice);
		}
	});
}
</script>

</HEAD>
<BODY>
<?php
$item_quantity = 0;
$item_price = 0;
$deliveryfee=0;
  $conciergefee=0;
$cartItem = $shoppingCart->getMemberCartItem($member_id);
if (! empty($cartItem)) {

    if (! empty($cartItem)) {
        foreach ($cartItem as $item) {
            $item_quantity = $item_quantity + $item["quantity"];
            $item_price = $item_price + ($item["price"] * $item["quantity"]);
        }
    }



}
?>
    <div id="shopping-cart">
        <div class="txt-heading">
            <div class="txt-heading-label">Shopping Cart</div>

            <a id="btnEmpty" href="cart.php?action=empty"><img
                src="empty-cart.png" alt="empty-cart" title="Empty Cart"
                class="float-right" /></a>
            <div class="cart-status">
              <?php if($item_quantity==0){
                $item_quantity=0;
                $item_price=0;
                $conciergefee=0;
                $deliveryfee=0;

              } else {
                $conciergefee=99;
              }?>

                <div>Total Quantity: <span id="total-quantity"><?php echo $item_quantity; ?></span></div>
                <div>Sub Total Price: <span id="total-price"><?php echo $item_price; ?></span></div>
                  <div>Concierge: <span id="total-price"><?php echo $conciergefee; ?></span></div>
                  <?php if ($item_price >=2500 || $item_quantity==0){
                    $deliveryfee=0;//compute for tot
                   ?>
                    <div>Delivery fee: <span id="total-price"><?php echo $deliveryfee; ?></span></div>
                  <div>Total Price: <span id="total-price"><?php echo $deliveryfee + $item_price + $conciergefee; ?></span></div>
                <?php  $_SESSION["finalTotal"]=$deliveryfee + $item_price + $conciergefee;}else{
                    $deliveryfee=40//compute for total
?>
                  <div>Delivery fee: <span id="total-price"><?php echo $deliveryfee ; ?></span></div>
                <div>Total Price: <span id="total-price"><?php echo $deliveryfee + $item_price + $conciergefee; ?></span></div>
              <?php $_SESSION["finalTotal"]=$deliveryfee + $item_price + $conciergefee;}


$_SESSION["total_qty"]=$item_quantity;
$_SESSION["subTotalPrice"]=$item_price;
$_SESSION["concierge"]=$conciergefee;
$_SESSION["deliveryfee"]=$deliveryfee;

              ?>
            </div>
        </div>
<?php
if (! empty($cartItem)) {
    ?>
<div class="shopping-cart-table">
            <div class="header">
                <div class="cart-info title">Title</div>
                <div class="cart-info">Quantity</div>
                <div class="cart-info price">Price</div>
            </div>
<?php
    foreach ($cartItem as $item) {
        ?>
				<div class="">
                <div class="cart-info title">
                    <?php echo $item["name"]; ?>
                </div>

                <div class="cart-info quantity">
                    <div class="btn-increment-decrement" onClick="decrement_quantity(<?php echo $item["cart_id"]; ?>, '<?php echo $item["price"]; ?>')">-</div><input class="input-quantity"
                        id="input-quantity-<?php echo $item["cart_id"]; ?>" value="<?php echo $item["quantity"]; ?>"><div class="btn-increment-decrement"
                        onClick="increment_quantity(<?php echo $item["cart_id"]; ?>, '<?php echo $item["price"]; ?>')">+</div>
                </div>

                <div class="cart-info price" id="cart-price-<?php echo $item["cart_id"]; ?>">
                        <?php echo "PHP". ($item["price"] * $item["quantity"]); ?>
                    </div>


                <div class="cart-info action">
                    <a
                        href="freshmeat.php?action=remove&id=<?php echo $item["cart_id"]; ?>"
                        class="btnRemoveAction"><img
                        src="icon-delete.png" alt="icon-delete"
                        title="Remove Item" /></a>
                </div>
            </div>
				<?php
    }
    ?>
</div>
  <?php
}
?>
</div>


</BODY>
</HTML>
